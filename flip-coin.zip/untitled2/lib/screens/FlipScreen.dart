import 'dart:math';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class FlipScreen extends StatefulWidget {
  @override
  _FlipScreenState createState() => _FlipScreenState();
}

class _FlipScreenState extends State<FlipScreen> {
  late VideoPlayerController _controller;
  bool _isVideoLoaded = false;
  String? _resultText;

  void _startVideo() {

    double randomValue = Random().nextDouble();
    bool isHeads = randomValue < 0.5;
    String videoAsset = isHeads ? 'assets/1-flip.mp4' : 'assets/B-flip.mp4';
    String resultText = isHeads ? 'نقش' : 'طرة';


    _controller = VideoPlayerController.asset(videoAsset)
      ..initialize().then((_) {
        setState(() {
          _isVideoLoaded = true;
          _resultText = resultText;
          _controller.play();
        });


        _controller.setLooping(false);
        _controller.addListener(() {
          if (_controller.value.position == _controller.value.duration) {
            setState(() {
              _isVideoLoaded = false;
            });
          }
        });
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [

          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/1-flip-pic.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),

          if (_isVideoLoaded)
            Center(
              child: AspectRatio(
                aspectRatio: _controller.value.aspectRatio,
                child: VideoPlayer(_controller),
              ),
            ),

          if (_resultText != null)
            Positioned(
              top: 40,
              left: 0,
              right: 0,
              child: Text(
                _resultText!,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),

          Positioned(
            bottom: 50,
            left: 0,
            right: 0,
            child: Center(
              child: ElevatedButton(
                onPressed: _startVideo,
                child: Text('انطلق'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
